#ifndef CALLBACKS_H
#define CALLBACKS_H

#include <xui.h>

/* Registra as callbacks na BC (PP_iInitLib).
   Chamar uma vez, depois do GuiInit e antes do PP_Open. */
void Callbacks_Init(XuiFont *font);

/* Teste 1: desenha direto na tela, sem passar pela BC */
void Callbacks_TesteDireto(void);

#endif
